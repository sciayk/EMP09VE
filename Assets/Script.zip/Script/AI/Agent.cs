﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Agent {
	public Transform m_AgentTrans;
	public float m_fProbeLength;
	public float m_fCollisionRadius;
	public float m_fNeighborRange;
	public float m_fAttackRange;
	public float m_fSightAngle;
	public float m_fSpeed;
	public float m_fMaxSpeed;
	public float m_fMaxRot;
	public float m_fRotAcc;
	public float m_fSeparationFactor;
	public float m_fCohesionFactor;
//	public float m_fAlignmentFactor;
	public bool m_bDiscover;
	public bool m_bFight;
	public string m_sAgentType;
	public int m_iIndex;
	public int m_iTeam;
	public Vector3 m_vTargetPos;
	public Obstacle[] m_arrObstacle;
}
